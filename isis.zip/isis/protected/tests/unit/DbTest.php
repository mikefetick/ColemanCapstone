<?php
class DbTest extends CTestCase
{
	public function testConnection()
	{
		$this->assertTrue(true);
	}
}
?>