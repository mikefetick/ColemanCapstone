<?php
/* @var $this MessageController */

$this->breadcrumbs=array(
	'Message'=>array('/message'),
	'Goodbye',
);
?>
<h1>Goodbye Yii Developer!</h1>
<h3><?php echo $time; ?></h3>
<a href="/helloworld/index.php?r=message/hello">Hello! - Easy Method: HTML anchor tag and a hard-coded, hyperlink</a></br>
<p><?php echo CHtml::Link('Hello! - Best Method: Yii CHtml helper method builds a hyperlink from the controllerID/actionID pair.',
array('message/hello')); ?></p>
