<?php
/* @var $this MessageController */

$this->breadcrumbs=array(
	'Message'=>array('/message'),
	'Hello',
);
?>
<h1>Hello World!</h1>
<h3><?php echo $time; ?></h3>
<a href="/helloworld/index.php?r=message/goodbye">Goodbye! - Easy Method: HTML anchor tag and a hard-coded, hyperlink</a></br>
<p><?php echo CHtml::Link('Goodbye! - Best Method: Yii CHtml helper method builds a hyperlink from the controllerID/actionID pair.',
array('message/goodbye')); ?></p>
