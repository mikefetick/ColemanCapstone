<?php
class DbTest extendes CTestCase
{
	public function testConnection()
	{
		$this->assertTrue(true);
	}
}
